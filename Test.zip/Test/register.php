<?php
	require 'dbconfig/config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>REGISTRATION FORM</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style= "background:url(images/1.jpg); background-size:100% 100%; height:640px" >

	<div id="main-wrapper">
	<center>
		<h1 style="font-family:Bebas Neue; color:#dcdde1;">REGISTRATION FORM</h1>
		<img src="images/2.png" class="flatpic"/>
	</center>
	
	<form class="myform" action="register.php" method="post">
		<label>USERNAME:</label><br>
		<input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br>
		<label>PASSWORD:</label><br>
		<input name="password" type="password" class="inputvalues" placeholder="Your password"required/><br>
		<label>CONFIRM PASSWORD:</label><br>
		<input name="cpassword" type="password" class="inputvalues" placeholder="Confirm password"required/><br>
		<input name="submit_btn" type="submit" id="signup_btn" value="SIGNUP"/><br>
		<a href="login.php"><input type="button" id="back_btn" value="BACK TO LOGIN"/></a>
	
	</form>
	 
	<?php
		if(isset($_POST['submit_btn']))
		{
			//echo '<script type="text/javascript"> alert("Signup button clicked")</script>';
			$username= $_POST['username'];
			$password= $_POST['password'];
			$cpassword= $_POST['cpassword'];
			
			if ($password==$cpassword)
			{
				$query="select * from users WHERE username='$username'";
				$queryrun = mysqli_query($con,$query);
				if(mysqli_num_rows($queryrun)>0)
				{
					echo '<script type="text/javascript"> alert("Already exist")</script>';
				}
				else
				{
					$query="insert into user values('$username','$password')";
					$queryrun = mysqli_query($con,$query);
					
					if($queryrun)
					{
						echo '<script type="text/javascript"> alert("Registered")</script>';
					}
					else
					{
						echo '<script type="text/javascript"> alert("Error")</script>';
					}
				}
			}
		}
	?>
	
	</div>
</body>
</html>