<?php

	session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>HOMEPAGE</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style= "background:url(images/1.jpg); background-size:100% 100%; height:640px" >

	<div id="main-wrapper">
	<center>
		<h1 style="font-family:Bebas Neue; color:#dcdde1;">HOMEPAGE</h1>
		<h3>WELCOME
			<?php echo $_SESSION['username']?>
		</h3>
		<img src="images/2.png" class="flatpic"/>
	</center>
	
	<form class="myform" action="login.php" method="post">
		
		<input name="logout" type="button" id="logout_btn" value="LOGOUT"/><br>
	
	</form>
	<?php
		if(isset($_POST['logout']))
		{
		session_destroy();
		header('location:login.php');
		}
	?>
	</div>

</body>
</html>