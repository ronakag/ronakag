<?php
	session_start();
	require 'dbconfig/config.php';

?>
<!DOCTYPE html>
<html>
<head>
<title>Test Page</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style= "background:url(images/1.jpg); background-size:100% 100%; height:640px" >

	<div id="main-wrapper">
	<center>
		<h1 style="font-family:Ariel Black; color:#dcdde1;">LOGIN FORM</h1>
		<img src="images/2.png" class="flatpic"/>
	</center>
	
	<form class="myform" action="login.php" method="post">
		<label><font face = "Ariel Black">USERNAME:</font></label><br>
		<input name="username" type="text" class="inputvalues" placeholder="Type your username" required/><br>
		<label>PASSWORD:</label><br>
		<input name="password" type="password" class="inputvalues" placeholder="Type your password" required/><br>
		<input name="login" type="submit" id="login_btn" value="LOGIN"/><br>
		<a href="register.php"><input type="button" id="register_btn" value="REGISTER"/></a>
	
	</form>
	<?php
	if(isset($_POST['login']))
	{
		$username=$_POST['username'];
		$password=$_POST['password'];
		$query="select * from users where username='$username' AND password='$password'";
		$queryrun=mysqli_query($con,$query);
		if(mysqli_num_rows($queryrun)>0)
		{
			$_SESSION['username']=$username;
			header('location:homepage.php');
		}
		else
		{
			echo '<script type="text/javascript"> alert("invalid")</script>';
		}
		
	}
	?>
	</div>

</body>
</html>